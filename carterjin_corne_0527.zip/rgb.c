#pragma once

void rgb_by_layer(int layer) {
#ifdef RGBLIGHT_ENABLE
    rgblight_mode_noeeprom(RGBLIGHT_MODE_STATIC_LIGHT);
#elif RGB_MATRIX_ENABLE
    rgb_matrix_mode_noeeprom(RGB_MATRIX_SOLID_COLOR);
#endif

    switch (layer) {        
        case 0:
            rgblight_sethsv_noeeprom(HSV_OFF);
            break;
        case 1:
            rgblight_sethsv_noeeprom(HSV_YELLOW);
            break;
        case 2:
            rgblight_sethsv_noeeprom(HSV_RED);
            break;
        case 3:
            rgblight_sethsv_noeeprom(HSV_CYAN);
            break;
        case 4:
            rgblight_sethsv_noeeprom(HSV_BLUE);
            break;
        default:
            rgblight_sethsv_noeeprom(HSV_GREEN);
    }
}
